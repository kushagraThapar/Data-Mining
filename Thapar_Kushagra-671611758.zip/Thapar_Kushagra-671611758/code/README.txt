Contents:
    Initiator.py -> Python program which initiates the whole algorithm
    MSAprioriImplementation.y -> Python program which is the implementation of the MS Apriori Algorithm
    Utils.py -> Python file containing some utility functions
    CustomConstants.py -> Python file containing constants


How to run this program: USAGE : python3 Initiator.py <input-data.txt> <parameter-file.txt>

